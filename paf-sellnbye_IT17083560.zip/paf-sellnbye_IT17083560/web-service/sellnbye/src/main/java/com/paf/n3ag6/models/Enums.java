package com.paf.n3ag6.models;

public class Enums {
	
	public enum UserType {
		
		Admin,Seller,Buyer
		
	}
}