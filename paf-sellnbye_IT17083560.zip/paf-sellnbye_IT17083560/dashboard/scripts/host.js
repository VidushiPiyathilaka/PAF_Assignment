var getHost = function(){
    return "http://localhost:8080/sellnbye/api/";
}